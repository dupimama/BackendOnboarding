package net.nvsoftware.iServiceRegistry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IServiceRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(IServiceRegistryApplication.class, args);
	}

}
