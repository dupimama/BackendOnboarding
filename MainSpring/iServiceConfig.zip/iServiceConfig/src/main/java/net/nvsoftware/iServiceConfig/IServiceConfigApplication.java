package net.nvsoftware.iServiceConfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IServiceConfigApplication {

	public static void main(String[] args) {
		SpringApplication.run(IServiceConfigApplication.class, args);
	}

}
