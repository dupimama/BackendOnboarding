package net.nvsoftware.iProductService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IProductServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
